#include "mainwindow.h"
#include "ui_mainwindow.h"
#include <QtNetwork>
#include <QMessageBox>

MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::MainWindow)
{
    ui->setupUi(this);

    setWindowTitle("Pokedex");

    setFixedSize(QSize(800, 542));

    QPixmap bkgnd(":/pokeRessources/pokedex_bg.png");
    bkgnd = bkgnd.scaled(this->size(), Qt::KeepAspectRatio);
    QPalette palette;
    palette.setBrush(QPalette::Background, bkgnd);
    this->setPalette(palette);
}

MainWindow::~MainWindow()
{
    delete pokemonReply;
    delete ui;
}

void MainWindow::getPokemon(int id) {
    pokemonReply = qnam.get(QNetworkRequest(QUrl("https://pokeapi.co/api/v2/pokemon/" + QString::number(id))));
    connect(pokemonReply, SIGNAL(finished()), this, SLOT(managePokemonReply()));
}

void MainWindow::on_searchButton_clicked()
{
    int search = ui->searchTerm->text().toInt();
    if (search == 0) {
        search = 25;
        ui->searchTerm->setText("25");
    }
    getPokemon(search);
}

void MainWindow::managePokemonReply()
{
    QString source = pokemonReply->readAll();
    //qDebug() << source;
    QJsonObject pokeData;
    QJsonDocument doc = QJsonDocument::fromJson(source.toUtf8());
    if(!doc.isNull()) {
        if(doc.isObject()) {
            pokeData = doc.object();
            // Pokemon's Name
            if (pokeData.contains("name") && pokeData["name"].isString()) {
                ui->pokeName->setText(pokeData["name"].toString());
            }
            // Pokemon's Image

            // Pokemon's Type

        }
        else {
            qDebug() << "Document is not an object" << endl;
        }
    }
    else {
        qDebug() << "Invalid JSON...\n" << source << endl;
    }
}
